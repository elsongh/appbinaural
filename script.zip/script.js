
let audioCtx;
let isPlaying = false;
let startTime = 0;
let elapsedTime = 0;
let intervalId;
let oscillators = [];
let gains = [];
let merger;
let noiseSource = null;
let noiseGain = null;
const totalDuration = 50 * 60; // 50 minutos em segundos

const segments = [
  { duration: 10 * 60, startBeat: 15, endBeat: 20 },
  { duration: 10 * 60, startBeat: 20, endBeat: 33 },
  { duration: 15 * 60, startBeat: 33, endBeat: 40 },
  { duration: 15 * 60, startBeat: 40, endBeat: 40 }
];


function createBinauralOscillators(currentElapsed) {
  clearAudio();
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  merger = audioCtx.createChannelMerger(2);

  let freqRight = 659;
  let gainValue = parseFloat(document.getElementById("volume").value);

  let segmentStart = 0;
  let now = audioCtx.currentTime;
  let playStart = now;
  let elapsed = currentElapsed;

  // --- Ruído de fundo ---
  const noiseType = document.getElementById("noiseType").value;
  if (noiseType !== "none") {
    // Gerador de ruído procedural
    const bufferSize = 2 * audioCtx.sampleRate;
    const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    if (noiseType === "white") {
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
    } else if (noiseType === "pink") {
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < bufferSize; i++) {
        let white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        output[i] *= 0.11; // (roughly) compensate for gain
        b6 = white * 0.115926;
      }
    } else if (noiseType === "brown") {
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        let white = Math.random() * 2 - 1;
        output[i] = (lastOut + (0.02 * white)) / 1.02;
        lastOut = output[i];
        output[i] *= 3.5; // (roughly) compensate for gain
      }
    }
    noiseSource = audioCtx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;
    noiseGain = audioCtx.createGain();
    // Volume inicial do ruído pelo controle
    let noiseVol = parseFloat(document.getElementById("noiseVolume").value);
    noiseGain.gain.value = noiseVol;
    noiseSource.connect(noiseGain).connect(audioCtx.destination);
    noiseSource.start();
  }

  // --- Binaural ---
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    let segElapsed = Math.max(0, elapsed - segmentStart);
    let segDuration = seg.duration - segElapsed;
    if (segDuration <= 0) {
      segmentStart += seg.duration;
      continue;
    }

    // Osciladores
    const oscLeft = audioCtx.createOscillator();
    const oscRight = audioCtx.createOscillator();
    const gainLeft = audioCtx.createGain();
    const gainRight = audioCtx.createGain();

    oscLeft.type = 'sine';
    oscRight.type = 'sine';
    oscRight.frequency.setValueAtTime(freqRight, playStart);

    // Ramp de frequência para batimento
    oscLeft.frequency.setValueAtTime(freqRight - (seg.startBeat + ((seg.endBeat - seg.startBeat) * segElapsed / seg.duration)), playStart);
    oscLeft.frequency.linearRampToValueAtTime(freqRight - seg.endBeat, playStart + segDuration);

    gainLeft.gain.value = gainValue;
    gainRight.gain.value = gainValue;

    oscLeft.connect(gainLeft).connect(merger, 0, 0);
    oscRight.connect(gainRight).connect(merger, 0, 1);

    oscLeft.start(playStart);
    oscRight.start(playStart);
    oscLeft.stop(playStart + segDuration);
    oscRight.stop(playStart + segDuration);

    oscillators.push(oscLeft, oscRight);
    gains.push(gainLeft, gainRight);

    playStart += segDuration;
    segmentStart += seg.duration;
    elapsed -= seg.duration;
    if (segmentStart >= totalDuration) break;
  }

  merger.connect(audioCtx.destination);
}


function clearAudio() {
  if (oscillators.length) {
    oscillators.forEach(osc => {
      try { osc.stop(); } catch {}
      try { osc.disconnect(); } catch {}
    });
    oscillators = [];
  }
  if (gains.length) {
    gains.forEach(g => { try { g.disconnect(); } catch {} });
    gains = [];
  }
  if (noiseSource) {
    try { noiseSource.stop(); } catch {}
    try { noiseSource.disconnect(); } catch {}
    noiseSource = null;
  }
  if (noiseGain) {
    try { noiseGain.disconnect(); } catch {}
    noiseGain = null;
  }
  if (merger) {
    try { merger.disconnect(); } catch {}
    merger = null;
  }
  if (audioCtx) {
    try { audioCtx.close(); } catch {}
    audioCtx = null;
  }
}

function startBinaural() {
  if (isPlaying) return;
  createBinauralOscillators(elapsedTime / 1000);
  startTime = Date.now() - elapsedTime;
  intervalId = setInterval(updateTime, 1000);
  isPlaying = true;
  document.getElementById("pauseButton").textContent = "Pausar";
}

function pauseBinaural() {
  if (!audioCtx) return;
  if (isPlaying) {
    audioCtx.suspend();
    clearInterval(intervalId);
    elapsedTime += Date.now() - startTime;
    isPlaying = false;
    document.getElementById("pauseButton").textContent = "Retomar";
  } else {
    audioCtx.resume();
    startTime = Date.now();
    intervalId = setInterval(updateTime, 1000);
    isPlaying = true;
    document.getElementById("pauseButton").textContent = "Pausar";
  }
}

function stopBinaural() {
  clearAudio();
  clearInterval(intervalId);
  isPlaying = false;
  elapsedTime = 0;
  document.getElementById("progress").value = 0;
  document.getElementById("tempo").textContent = "Tempo: 0:00 / 50:00 - Diferença: 0.00 Hz";
  document.getElementById("pauseButton").textContent = "Pausar";
}

function updateTime() {
  let elapsed = Math.floor((elapsedTime + (Date.now() - startTime)) / 1000);
  if (elapsed >= totalDuration) {
    stopBinaural();
    return;
  }
  let min = Math.floor(elapsed / 60);
  let sec = elapsed % 60;
  document.getElementById("progress").value = (elapsed / totalDuration) * 100;

  // Batimento
  let segmentStart = 0;
  let beatFreq = 0;
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    if (elapsed < segmentStart + seg.duration) {
      const segElapsed = elapsed - segmentStart;
      beatFreq = seg.startBeat + ((seg.endBeat - seg.startBeat) * segElapsed / seg.duration);
      break;
    }
    segmentStart += seg.duration;
  }

  document.getElementById("tempo").textContent =
    `Tempo: ${min}:${sec.toString().padStart(2, '0')} / 50:00 - Diferença: ${beatFreq.toFixed(2)} Hz`;
}



// Volume dinâmico do áudio principal
document.getElementById("volume").addEventListener("input", function () {
  const gainValue = parseFloat(this.value);
  gains.forEach(g => g.gain.value = gainValue);
});

// Volume dinâmico do ruído
document.getElementById("noiseVolume").addEventListener("input", function () {
  const noiseVol = parseFloat(this.value);
  if (noiseGain) noiseGain.gain.value = noiseVol;
});


// Progresso interativo
document.getElementById("progress").addEventListener("input", function () {
  if (!isPlaying) {
    elapsedTime = (parseFloat(this.value) / 100) * totalDuration * 1000;
    updateTime();
  } else {
    elapsedTime = (parseFloat(this.value) / 100) * totalDuration * 1000;
    clearAudio();
    createBinauralOscillators(elapsedTime / 1000);
    startTime = Date.now() - elapsedTime;
    updateTime();
  }
});

// Troca de ruído de fundo ao vivo
document.getElementById("noiseType").addEventListener("change", function () {
  if (isPlaying) {
    clearAudio();
    createBinauralOscillators(((Date.now() - startTime) + elapsedTime) / 1000);
  }
});

document.getElementById("startButton").addEventListener("click", function () {
  stopBinaural();
  startBinaural();
});
document.getElementById("pauseButton").addEventListener("click", pauseBinaural);

document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("tempo").textContent = "Tempo: 0:00 / 50:00 - Diferença: 0.00 Hz";
  document.getElementById("progress").value = 0;
});

// ...existing code...
document.getElementById("stopButton").addEventListener("click", stopBinaural);
// ...existing code...